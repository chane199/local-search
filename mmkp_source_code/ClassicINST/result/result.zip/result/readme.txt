parameter threshold 1: n*m, 02/11/2014, 17:02
